Package Content
---------------
bibliography:
      This is where you place bibliography files that contain the references to be inserted
in the Bibliography part of the thesis.


figures:
   This is where I placed the figures. The folder may be divided further
by chapter if you want.


src:
   This is where you can find the files you'll have to edit for your thesis.
I suggest you add your thesis chapters here too.


private:
   Files in the "private" folder are made such that they don't need to be
edited. So, do NOT edit them unless you know what you are doing.


00readme.txt:
   This file.


uo-ethesis.tex:
   The master file of the thesis.


